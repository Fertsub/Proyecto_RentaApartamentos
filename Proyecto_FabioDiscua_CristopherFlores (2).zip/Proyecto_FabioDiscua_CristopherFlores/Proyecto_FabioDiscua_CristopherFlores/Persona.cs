﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_FabioDiscua_CristopherFlores
{
    internal class Persona
    {
        private int _dni;
        private string? _nombre;
        private string? _apellido;
        private string? _telefono;
        private string? _correo;

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor por defecto de la clase Persona.
         */
        public Persona() { }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor de la clase Persona.
         * @param dni DNI de la persona.
         * @param nombre Nombre de la persona.
         * @param apellido Apellido de la persona.
         * @param telefono Teléfono de la persona.
         * @param correo Correo electrónico de la persona.
         */
        public Persona(int dni, string? nombre, string? apellido, string? telefono, string? correo)
        {
            _dni = dni;
            _nombre = nombre;
            _apellido = apellido;
            _telefono = telefono;
            _correo = correo;
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el DNI de la persona.
         */
        public int Dni { get => _dni; set => _dni = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el nombre de la persona.
         */
        public string? Nombre { get => _nombre; set => _nombre = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el apellido de la persona.
         */
        public string? Apellido { get => _apellido; set => _apellido = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el teléfono de la persona.
         */
        public string? Telefono { get => _telefono; set => _telefono = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el correo electrónico de la persona.
         */
        public string? Correo { get => _correo; set => _correo = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Sobreescribe el método ToString() para mostrar la información de la persona.
         * @return Una cadena con la información de la persona.
         */
        public override string ToString()
        {
            return $"\nDNI:  {Dni} | Nombre: {Nombre} | Apellido: {Apellido} | Teléfono: {Telefono} | Correo: {Correo} | ";
        }
    }
}
