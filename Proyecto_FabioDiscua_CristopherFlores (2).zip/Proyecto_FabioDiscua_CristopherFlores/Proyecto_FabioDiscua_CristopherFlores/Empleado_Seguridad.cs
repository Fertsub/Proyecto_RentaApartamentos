﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_FabioDiscua_CristopherFlores
{

    /**
     * Autor: Cristopher Alexander Flores Miranda
     * Fecha: 17/02/2025
     * Representa a un empleado de seguridad.
     */
    internal class Empleado_Seguridad : Empleado
    {
        private string? _turno;
        private bool _armado;

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor por defecto de la clase Empleado_Seguridad.
         */
        public Empleado_Seguridad() { }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor de la clase Empleado_Seguridad.
         * @param idEmpleado ID del empleado.
         * @param sueldo Sueldo del empleado.
         * @param dechaContratacion Fecha de contratación del empleado.
         * @param activo Indica si el empleado está activo.
         * @param turno Turno del empleado de seguridad.
         * @param armado Indica si el empleado está armado.
         */
        public Empleado_Seguridad(int idEmpleado, double sueldo, DateTime dechaContratacion, bool activo, string? turno, bool armado) : base(idEmpleado, sueldo, dechaContratacion, activo)
        {
            _turno = turno;
            _armado = armado;
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el turno del empleado de seguridad.
         */
        public string? Turno { get => _turno; set => _turno = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece si el empleado está armado.
         */
        public bool Armado { get => _armado; set => _armado = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Calcula el pago del empleado de seguridad (implementación pendiente).
         * @return El pago calculado (actualmente lanza una excepción).
         */
        public override double CalculoPago()
        {
            // Aquí iría la lógica para calcular el pago del empleado de seguridad
            // En base a su sueldo, horas extras, etc.
            throw new NotImplementedException();
        }
    }
}

