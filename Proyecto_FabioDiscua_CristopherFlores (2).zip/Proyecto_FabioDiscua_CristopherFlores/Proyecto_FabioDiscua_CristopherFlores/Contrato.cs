﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_FabioDiscua_CristopherFlores
{
    internal class Contrato
    {

        private int _idCont;
        internal Apartamento? apartamento;
        internal Arrendador? arrendador;
        private DateTime _fechaInicio;
        private DateTime _fechaFin;
        private float _cuota;
        private int _estado;

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor por defecto de la clase Contrato.
         */
        public Contrato()
        {
            Arrendador = new Arrendador();
            Apartamento = new Apartamento();
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor de la clase Contrato.
         * @param apartamento Apartamento del contrato.
         * @param arrendador Arrendador del contrato.
         * @param fechaInicio Fecha de inicio del contrato.
         * @param fechaFin Fecha de fin del contrato.
         * @param cuota Cuota del contrato.
         * @param estado Estado del contrato.
         */
        public Contrato(Apartamento apartamento, Arrendador arrendador, DateTime fechaInicio, DateTime fechaFin, float cuota, int estado)
        {
            Apartamento = apartamento;
            Arrendador = arrendador;
            FechaInicio = fechaInicio;
            FechaFin = fechaFin;
            Cuota = cuota;
            Estado = estado;
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el ID del contrato.
         */
        public int IdCont { get => _idCont; set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Id Inválido");
                }
                else
                {
                    _idCont = value;
                }
            }
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el Apartamento del contrato.
         */
        internal Apartamento Apartamento { get => apartamento; set => apartamento = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el Arrendador del contrato.
         */
        internal Arrendador Arrendador { get => arrendador; set => arrendador = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la Fecha de Inicio del contrato.
         */
        public DateTime FechaInicio { get => _fechaInicio; set
            {
                if (value == DateTime.MinValue)
                {
                    throw new ArgumentException("La fecha de inicio no puede ser la fecha mínima.");
                }

                if (value > DateTime.Now)
                {
                    throw new ArgumentException("La fecha de inicio no puede ser una fecha futura.");
                }
                    
                _fechaInicio = value;
            }
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la Fecha de Fin del contrato.
         */
        public DateTime FechaFin { get => _fechaFin; set => _fechaFin = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la Cuota del contrato.
         */
        public float Cuota { get => _cuota; set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Cuota Inválida");
                }
                else
                {
                    _cuota = value;
                }
            }
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el Estado del contrato.
         */
        public int Estado { get => _estado; set => _estado = (value == 1) ? 1 : 0;}

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Sobreescribe el método ToString() para mostrar la información del contrato.
         * @return Una cadena con la información del contrato.
         */
        public override string ToString()
        {
            string estadoTexto = (_estado == 1) ? "Activo" : "Inactivo";
            return $"\n[CONTRATOS]: ID del Contrato: {IdCont} | Apartamento: {Apartamento} | Arrendador: {Arrendador} | Fecha de Inicio: {FechaInicio} | Fecha de Finalización: {FechaFin} | Cuota: {Cuota} | Estado: {estadoTexto}";
        }

        /*
            Autor: [Cristopher Alexander Flores Miranda]
            Fecha: [23/02/2025]
            Parámetros: Ninguno
            Descripción: Gestiona las operaciones relacionadas con la clase Contrato.
        */
        public static void Agregar(List<Contrato> listContratos, List<Apartamento> listApartamentos, List<Arrendador> listArrendadores)
        {
            Console.WriteLine("===== AÑADIR NUEVO CONTRATO =====");

            Console.Write("Ingrese el ID del Contrato: ");
            int idContrato = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\n***** Lista de Apartamentos *****");
            if (listApartamentos.Count == 0)
            {
                Console.WriteLine("No hay apartamentos registrados. Operación cancelada.");
                return;
            }
            foreach (Apartamento itApartamento in listApartamentos)
            {
                Console.WriteLine($"itApartamento");
            }

            Console.Write("\nIngrese el ID del Apartamento: ");
            int idAptoSeleccionado = Convert.ToInt32(Console.ReadLine());

            Apartamento? apartamentoSeleccionado = listApartamentos.FirstOrDefault(a => a.IdApartamento == idAptoSeleccionado);

            if (apartamentoSeleccionado == null)
            {
                Console.WriteLine("Apartamento no encontrado. Operación cancelada.");
                return;
            }

            Console.Write("\nIngrese el ID (DNI) del Arrendador: ");
            int dniArrendadorSeleccionado = Convert.ToInt32(Console.ReadLine());

            Arrendador? arrendadorSeleccionado = listArrendadores.FirstOrDefault(ar => ar.Dni == dniArrendadorSeleccionado);

            if (arrendadorSeleccionado == null)
            {
                Console.WriteLine("Arrendador no encontrado. Operación cancelada.");
                return;
            }

            Console.Write("Ingrese la fecha de inicio (YYYY-MM-DD): ");
            DateTime fechaInicio = DateTime.Parse(Console.ReadLine() ?? "1900-01-01");

            Console.Write("Ingrese la fecha de fin (YYYY-MM-DD): ");
            DateTime fechaFin = DateTime.Parse(Console.ReadLine() ?? "1900-01-01");

            Console.Write("Ingrese la cuota mensual: ");
            float cuota = float.Parse(Console.ReadLine() ?? "0");

            Console.Write("Ingrese el estado (1: Activo, 0: Inactivo): ");
            int estado = Convert.ToInt32(Console.ReadLine());

            Contrato nuevoContrato = new Contrato(
                apartamentoSeleccionado,
                arrendadorSeleccionado,
                fechaInicio,
                fechaFin,
                cuota,
                estado
            );
            nuevoContrato.IdCont = idContrato;

            listContratos.Add(nuevoContrato);
            Console.WriteLine("¡Contrato añadido con éxito!");
        }

        public static void Eliminar(List<Contrato> listContratos)
        {
            if (listContratos.Count == 0)
            {
                Console.WriteLine("No hay contratos registrados.");
                return;
            }

            Console.WriteLine("===== ELIMINAR CONTRATO =====");

            Console.WriteLine("=== LISTA DE CONTRATOS ===");
            foreach (Contrato itContrato in listContratos)
            {
                Console.WriteLine(itContrato);
            }

            Console.Write("Ingrese el ID del Contrato a eliminar: ");
            int idEliminar = Convert.ToInt32(Console.ReadLine());

            Contrato? contratoEliminar = listContratos.FirstOrDefault(con => con.IdCont == idEliminar);

            if (contratoEliminar != null)
            {
                listContratos.Remove(contratoEliminar);
                Console.WriteLine("Contrato eliminado con éxito.");
            }
            else
            {
                Console.WriteLine("No se encontró un contrato con ese ID.");
            }
        }

        public static void Editar(List<Contrato> listContratos, List<Apartamento> listApartamentos, List<Arrendador> listArrendadores)
        {
            if (listContratos.Count == 0)
            {
                Console.WriteLine("No hay contratos registrados.");
                return;
            }

            Console.WriteLine("===== EDITAR CONTRATO =====");

            Console.WriteLine("=== LISTA DE CONTRATOS ===");
            foreach (Contrato itContrato in listContratos)
            {
                Console.WriteLine(itContrato);
            }

            Console.Write("Ingrese el ID del Contrato a editar: ");
            int idEditar = Convert.ToInt32(Console.ReadLine());

            Contrato? aptoEditar = listContratos.FirstOrDefault(con => con.IdCont == idEditar);

            if (aptoEditar != null)
            {
                Console.WriteLine("\n***** Lista de Apartamentos *****");
                if (listApartamentos.Count == 0)
                {
                    Console.WriteLine("No hay apartamentos registrados. Operación cancelada.");
                    return;
                }
                foreach (Apartamento itApartamento in listApartamentos)
                {
                    Console.WriteLine(itApartamento);
                }

                Console.Write("\nIngrese el ID del Apartamento: ");
                int idAptoSeleccionado = Convert.ToInt32(Console.ReadLine());

                Apartamento? apartamentoSeleccionado = listApartamentos.FirstOrDefault(a => a.IdApartamento == idAptoSeleccionado);

                if (apartamentoSeleccionado == null)
                {
                    Console.WriteLine("Apartamento no encontrado. Operación cancelada.");
                    return;
                }

                Console.Write("\nIngrese el ID (DNI) del Arrendador: ");
                int dniArrendadorSeleccionado = Convert.ToInt32(Console.ReadLine());

                Arrendador? arrendadorSeleccionado = listArrendadores.FirstOrDefault(ar => ar.Dni == dniArrendadorSeleccionado);

                if (arrendadorSeleccionado == null)
                {
                    Console.WriteLine("Arrendador no encontrado. Operación cancelada.");
                    return;
                }

                Console.Write("Ingrese la fecha de inicio (YYYY-MM-DD): ");
                DateTime nuevaFechaInicio = DateTime.Parse(Console.ReadLine() ?? "1900-01-01");

                Console.Write("Ingrese la fecha de fin (YYYY-MM-DD): ");
                DateTime nuevaFechaFin = DateTime.Parse(Console.ReadLine() ?? "1900-01-01");

                Console.Write("Ingrese la cuota mensual: ");
                float nuevaCuota = float.Parse(Console.ReadLine() ?? "0");

                Console.Write("Ingrese el estado (1: Activo, 0: Inactivo): ");
                int nuevoEstado = Convert.ToInt32(Console.ReadLine());

                aptoEditar.FechaInicio = nuevaFechaInicio;
                aptoEditar.FechaFin = nuevaFechaFin;
                aptoEditar.Cuota= nuevaCuota; ;
                aptoEditar.Estado= nuevoEstado;
                aptoEditar.Arrendador = arrendadorSeleccionado;
                aptoEditar.Apartamento = apartamentoSeleccionado;

                Console.WriteLine("Contrato editado con éxito.");
            }
            else
            {
                Console.WriteLine("No se encontró un contrato con ese ID.");
            }
        }
    }
}
