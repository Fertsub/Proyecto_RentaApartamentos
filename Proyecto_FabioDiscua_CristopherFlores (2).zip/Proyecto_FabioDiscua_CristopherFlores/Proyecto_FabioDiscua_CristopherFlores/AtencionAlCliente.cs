﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Proyecto_FabioDiscua_CristopherFlores;

namespace Practica5_Prestamos
{
    internal class AtencionAlCliente : Empleado
    {
        private string? _extTelefonica;
        List<string>? Idiomas;

        /**
          * Autor: Cristopher Alexander Flores Miranda
          * Fecha: 17/02/2025
          * Constructor por defecto de la clase AtencionAlCliente.
          */
        public AtencionAlCliente() { }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor de la clase AtencionAlCliente.
         * @param idEmpleado ID del empleado.
         * @param sueldo Sueldo del empleado.
         * @param dechaContratacion Fecha de contratacion del empleado.
         * @param activo Indica si el empleado esta activo.
         * @param extTelefonica Extensión telefónica del empleado.
         * @param idiomas Lista de idiomas que habla el empleado.
         */
        public AtencionAlCliente(int idEmpleado, double sueldo, DateTime dechaContratacion, bool activo, string? extTelefonica, List<string> idiomas) : base(idEmpleado, sueldo, dechaContratacion, activo)
        {
            _extTelefonica = extTelefonica;
            _Idiomas = idiomas;
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la extensión telefónica del empleado.
         */
        public string? ExtTelefonica { get => _extTelefonica; set => _extTelefonica = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Lista de idiomas que habla el empleado.
         */
        public List<string>? _Idiomas
        {
            get => Idiomas; set => Idiomas = value;
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Metodo para calcular el pago del empleado.
         * @return double
         */
        public override double CalculoPago()
        {
            throw new NotImplementedException();
        }
    }
}
