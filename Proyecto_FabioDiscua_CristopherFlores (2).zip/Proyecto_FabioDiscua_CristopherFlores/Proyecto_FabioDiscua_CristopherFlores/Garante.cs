﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_FabioDiscua_CristopherFlores
{
    internal class Garante : Persona
    {
        private int _idGarante;
        private string? _docAval;
        private Arrendatario arrendatario;

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor por defecto de la clase Garante.
         */
        public Garante()
        {
            arrendatario = new Arrendatario();
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor de la clase Garante.
         * @param dni DNI del garante.
         * @param nombre Nombre del garante.
         * @param apellido Apellido del garante.
         * @param telefono Teléfono del garante.
         * @param correo Correo del garante.
         * @param idGarante ID del garante.
         * @param docAval Documento de aval del garante.
         * @param arrendatario Arrendatario al que avala el garante.
         */
        public Garante(int dni, string? nombre, string? apellido, string? telefono, string? correo, int idGarante, string? docAval, Arrendatario arrendatario) : base(dni, nombre, apellido, telefono, correo)
        {
            _idGarante = idGarante;
            _docAval = docAval;
            this.arrendatario = arrendatario;
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el ID del garante.
         */
        public int IdGarante { get => _idGarante; set => _idGarante = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el documento de aval del garante.
         */
        public string? DocAval { get => _docAval; set => _docAval = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el arrendatario al que avala el garante.
         */
        internal Arrendatario Arrendatario { get => arrendatario; set => arrendatario = value; }
    }
}
