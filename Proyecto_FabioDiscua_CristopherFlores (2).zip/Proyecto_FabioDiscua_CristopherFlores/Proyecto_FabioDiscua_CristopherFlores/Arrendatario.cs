﻿using System;
using Proyecto_FabioDiscua_CristopherFlores;

namespace Proyecto_FabioDiscua_CristopherFlores
{
    internal class Arrendatario : Persona
    {
        private string? _idArrendatario;
        private int _edad;

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor por defecto de la clase Arrendatario.
         */
        public Arrendatario() { }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor de la clase Arrendatario.
         * @param dni DNI del arrendatario.
         * @param nombre Nombre del arrendatario.
         * @param apellido Apellido del arrendatario.
         * @param telefono Teléfono del arrendatario.
         * @param correo Correo del arrendatario.
         * @param idArrendatario ID del arrendatario.
         * @param edad Edad del arrendatario.
         */
        public Arrendatario(int dni, string? nombre, string? apellido, string? telefono, string? correo, string? idArrendatario, int edad) :
            base(dni, nombre, apellido, telefono, correo)
        {
            _idArrendatario = idArrendatario;
            _edad = edad;
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el ID del arrendatario.
         */
        public string? IdArrendatario { get => _idArrendatario; set
            {
                if (value == null)
                {
                    throw new ArgumentException("ID no ingresado");
                }
                else
                {
                    _idArrendatario = value;
                }
            }
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la edad del arrendatario.
         */
        public int Edad { get => _edad; set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Edad Inválida");
                }
                else
                {
                    _edad = value;
                }
            }
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Sobreescribe el método ToString() para mostrar la información del arrendatario.
         * @return Una cadena con la información del arrendatario.
         */
        public override string ToString()
        {
            return base.ToString() + $"ID del Arrendatario: {IdArrendatario}  | Edad: {Edad}";
        }

        public static void Agregar(List<Arrendatario> listArrendatarios)
        {
            Console.WriteLine("===== AÑADIR NUEVO ARRENDATARIO =====");

            Console.Write("DNI: ");
            int dni = Convert.ToInt32(Console.ReadLine());

            Console.Write("Nombre: ");
            string? nombre = Console.ReadLine();

            Console.Write("Apellido: ");
            string? apellido = Console.ReadLine();

            Console.Write("Teléfono: ");
            string? telefono = Console.ReadLine();

            Console.Write("Correo: ");
            string? correo = Console.ReadLine();

            Console.Write("ID del Arrendatario: ");
            string? idArrendatario = Console.ReadLine();

            Console.Write("Edad del Arrendatario: ");
            int edad = Convert.ToInt32(Console.ReadLine());

            Arrendatario nuevoArrendatario = new Arrendatario(
                dni,
                nombre,
                apellido,
                telefono,
                correo,
                idArrendatario,
                edad
            );

            listArrendatarios.Add(nuevoArrendatario);
            Console.WriteLine("¡Arrendatario añadido con éxito!");
        }
        
        public static void Eliminar(List<Arrendatario> listArrendatarios)
        {
            if (listArrendatarios.Count == 0)
            {
                Console.WriteLine("No hay arrendatarios registrados.");
                return;
            }

            Console.WriteLine("===== ELIMINAR ARRENDATARIO =====");

            Console.WriteLine("=== LISTA DE ARRENDATARIOS ===");
            foreach (Arrendatario itArrendatario in listArrendatarios)
            {
                Console.WriteLine(itArrendatario);
            }

            Console.Write("Ingrese el DNI del arrendador a eliminar: ");
            int dniEliminar = Convert.ToInt32(Console.ReadLine());

            Arrendatario? arrendatarioEliminar = listArrendatarios.FirstOrDefault(a => a.Dni == dniEliminar);

            if (arrendatarioEliminar != null)
            {
                listArrendatarios.Remove(arrendatarioEliminar);
                Console.WriteLine("Arrendatario eliminado con éxito.");
            }
            else
            {
                Console.WriteLine("No se encontró un arrendatario con ese DNI.");
            }
        }

        public static void Editar(List<Arrendatario> listArrendatarios)
        {
            if (listArrendatarios.Count == 0)
            {
                Console.WriteLine("No hay arrendatarios registrados.");
                return;
            }

            Console.WriteLine("===== EDITAR ARRENDATARIO =====");

            Console.WriteLine("=== LISTA DE ARRENDATARIOS ===");
            foreach (Arrendatario itArrendatario in listArrendatarios)
            {
                Console.WriteLine(itArrendatario);
            }

            Console.Write("Ingrese el DNI del arrendatario a editar: ");
            int dniEditar = Convert.ToInt32(Console.ReadLine());

            Arrendatario? aptoEditar = listArrendatarios.FirstOrDefault(a => a.Dni == dniEditar);

            if (aptoEditar != null)
            {

                Console.Write("Nuevo DNI: ");
                int nuevoDni = Convert.ToInt32(Console.ReadLine());

                Console.Write("Nuevo Nombre: ");
                string? nuevoNombre = Console.ReadLine();

                Console.Write("Nuevo Apellido: ");
                string? nuevoApellido = Console.ReadLine();

                Console.Write("Nuevo Teléfono: ");
                string? nuevoTelefono = Console.ReadLine();

                Console.Write("Nuevo Correo: ");
                string? nuevoCorreo = Console.ReadLine();

                Console.Write("Nuevo ID: ");
                string? nuevoId = Console.ReadLine();

                Console.Write("Nueva Edad: ");
                int nuevaEdad = Convert.ToInt32(Console.ReadLine());

                aptoEditar.Dni = nuevoDni;
                aptoEditar.Nombre = nuevoNombre;
                aptoEditar.Apellido = nuevoApellido;
                aptoEditar.Telefono = nuevoTelefono;
                aptoEditar.Correo = nuevoCorreo;
                aptoEditar.IdArrendatario= nuevoId;
                aptoEditar.Edad = nuevaEdad;
               
                Console.WriteLine("Arrendador editado con éxito.");
            }
            else
            {
                Console.WriteLine("No se encontró un arrendatario con ese DNI.");
            }
        }
    }
}
