﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_FabioDiscua_CristopherFlores
{
    internal class Apartamento
    {
        private int _idApartamento;
        private string? _direccion;
        private int _numHabitaciones;
        private float _precioAlquiler;
        private int _disponible;
        internal Arrendador arrendador;

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor por defecto de la clase Apartamento.
         */
        public Apartamento()
        {
            arrendador = new Arrendador();
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor de la clase Apartamento.
         * @param idApartamento ID del Apartamento.
         * @param direccion Dirección del Apartamento.
         * @param numHabitaciones Número de habitaciones del Apartamento.
         * @param precioAlquiler Precio de alquiler del Apartamento.
         * @param disponible Disponibilidad del Apartamento.
         * @param arrendador Arrendador del Apartamento.
         */
        public Apartamento(int idApartamento, string? direccion, int numHabitaciones, float precioAlquiler, int disponible, Arrendador arrendador)
        {
            IdApartamento = idApartamento;
            Direccion = direccion;
            NumHabitaciones = numHabitaciones;
            PrecioAlquiler = precioAlquiler;
            Disponible = disponible;
            Arrendador = arrendador;
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el ID del Apartamento.
         */
        public int IdApartamento { get => _idApartamento; set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Id Inválido");
                }
                else
                {
                    _idApartamento = value;
                }
            }
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la Dirección del Apartamento.
         */
        public string? Direccion { get => _direccion; set
            {
                if (value == null)
                {
                    throw new ArgumentException("Dirección No Ingresada");
                }
                else
                {
                    _direccion = value;
                }
            }
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el Número de Habitaciones del Apartamento.
         */
        public int NumHabitaciones { get => _numHabitaciones; set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Habitaciones no ingresadas");
                }
                else
                {
                    _numHabitaciones = value;
                }
            }
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el Precio de Alquiler del Apartamento.
         */
        public float PrecioAlquiler { get => _precioAlquiler; set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Precio no ingresado");
                }
                else
                {
                    _precioAlquiler = value;
                }
            }
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la Disponibilidad del Apartamento.
         */
        public int Disponible { get => _disponible; set => _disponible = (value == 1) ? 1 : 0; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el Arrendador del Apartamento.
         */
        internal Arrendador Arrendador { get => arrendador; set => arrendador = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * @return
         */
        public override string ToString()
        {
            string disponibilidad = (_disponible == 1) ? "Disponible" : "No Disponible";

            return $"[APARTAMENTOS]: ID Apartamento: {IdApartamento} | Dirección: {Direccion} | Disponible: {disponibilidad} | Alquiler: {PrecioAlquiler} | Arrendador: {Arrendador}";
        }

        /*
            Autor: [Cristopher Alexander Flores Miranda]
            Fecha: [23/02/2025]
            Parámetros: Ninguno
            Descripción: Gestión de las operaciones relacionadas a la clase Apartamento
        */

        public static void Agregar(List<Apartamento> listApartamentos, List<Arrendador> listArrendadores)
        {
            Console.WriteLine("===== AÑADIR NUEVO APARTAMENTO =====");

            Console.Write("ID del Apartamento: ");
            int idApartamento = Convert.ToInt32(Console.ReadLine());

            Console.Write("Dirección: ");
            string? direccion = Console.ReadLine();

            Console.Write("Número de Habitaciones: ");
            int numHabitaciones = Convert.ToInt32(Console.ReadLine());

            Console.Write("Precio de Alquiler (float): ");
            float precioAlquiler = float.Parse(Console.ReadLine() ?? "0");

            Console.Write("¿Está disponible? (1-Disponible/ 0-No Disponible): ");
            int disponible = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\n***** Lista de Arrendadores *****");
            if (listArrendadores.Count == 0)
            {
                Console.WriteLine("No hay arrendadores registrados.");
                return; 
            }

            foreach (Arrendador itArrendador in listArrendadores)
            {
                Console.WriteLine(itArrendador);
            }

            Console.Write("\nIngrese el ID del Arrendador: ");
            int idArrendador = Convert.ToInt32(Console.ReadLine());

            Arrendador? arrendadorSeleccionado = listArrendadores
                .FirstOrDefault(a => a.Dni == idArrendador);

            if (arrendadorSeleccionado == null)
            {
                Console.WriteLine("Arrendador no encontrado. Operación cancelada.");
                return;
            }

            Apartamento nuevoApartamento = new Apartamento(
                idApartamento,
                direccion,
                numHabitaciones,
                precioAlquiler,
                disponible,
                arrendadorSeleccionado
            );

            listApartamentos.Add(nuevoApartamento);

            Console.WriteLine("¡Apartamento añadido con éxito!");
        }

        public static void Eliminar(List<Apartamento> listApartamentos)
        {
            if (listApartamentos.Count == 0)
            {
                Console.WriteLine("No hay apartamentos registrados.");
                return;
            }

            Console.WriteLine("===== ELIMINAR APARTAMENTO =====");

            if (listApartamentos.Count > 0)
            {
                Console.WriteLine("=== LISTA DE APARTAMENTOS ===");
                foreach (Apartamento itApartamento in listApartamentos)
                {
                    Console.WriteLine(itApartamento);
                }
            }



            Console.Write("Ingrese el ID del apartamento a eliminar: ");
            int idEliminar = Convert.ToInt32(Console.ReadLine());

            Apartamento? aptoEliminar = listApartamentos.FirstOrDefault(a => a.IdApartamento == idEliminar);

            if (aptoEliminar != null)
            {
                listApartamentos.Remove(aptoEliminar);
                Console.WriteLine("Apartamento eliminado con éxito.");
            }
            else
            {
                Console.WriteLine("No se encontró un apartamento con ese ID.");
            }
        }

        public static void Editar(List<Apartamento> listApartamentos, List<Arrendador> listArrendadores) {
            if (listApartamentos.Count == 0)
            {
                Console.WriteLine("No hay apartamentos registrados.");
                return;
            }

            Console.WriteLine("===== EDITAR APARTAMENTO =====");

            Console.WriteLine("=== LISTA DE APARTAMENTOS ===");
            foreach (Apartamento itApartamento in listApartamentos)
            {
                Console.WriteLine(itApartamento);
            }

            Console.Write("Ingrese el ID del apartamento a editar: ");
            int idEditar = Convert.ToInt32(Console.ReadLine());

            Apartamento? aptoEditar = listApartamentos.FirstOrDefault(a => a.IdApartamento == idEditar);

            if (aptoEditar != null)
            {
                Console.Write("Nueva Dirección: ");
                string? nuevaDireccion = Console.ReadLine();

                Console.Write("Número de Habitaciones: ");
                int nuevoNumHab = Convert.ToInt32(Console.ReadLine());

                Console.Write("Precio de Alquiler (float): ");
                float nuevoPrecio = float.Parse(Console.ReadLine());

                Console.Write("¿Está disponible? (1-Disponible/0-No Disponible): ");
                int nuevoDisponible = Convert.ToInt32(Console.ReadLine());

                if (listArrendadores.Count == 0)
                {
                    Console.WriteLine("No hay arrendadores registrados.");
                    return;
                }

                foreach (Arrendador itArrendador in listArrendadores)
                {
                    Console.WriteLine(itArrendador);
                }

                Console.Write("\nIngrese el ID del Arrendador: ");
                int idArrendadorN = Convert.ToInt32(Console.ReadLine());

                Arrendador arrendadorSeleccionadoN = listArrendadores.FirstOrDefault(a => a.Dni == idArrendadorN);

                if (arrendadorSeleccionadoN == null)
                {
                    Console.WriteLine("Arrendador no encontrado. Operación cancelada.");
                    return;
                }

                aptoEditar.Direccion = nuevaDireccion;
                aptoEditar.NumHabitaciones = nuevoNumHab;
                aptoEditar.PrecioAlquiler = nuevoPrecio;
                aptoEditar.Disponible = nuevoDisponible;
                aptoEditar.Arrendador = arrendadorSeleccionadoN;


                Console.WriteLine("Apartamento editado con éxito.");
            }
            else
            {

                Console.WriteLine("No se encontró un apartamento con ese ID.");
            }

        }
    }
}