﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Proyecto_FabioDiscua_CristopherFlores;

namespace Proyecto_FabioDiscua_CristopherFlores
{
    internal class Empleado_Administrativo : Empleado
    {
        private string? _oficina;
        private string? _puesto;

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor por defecto de la clase Empleado_Administrativo.
         */
        public Empleado_Administrativo()
        {

        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor de la clase Empleado_Administrativo.
         * @param idEmpleado ID del empleado.
         * @param sueldo Sueldo del empleado.
         * @param dechaContratacion Fecha de contratacion del empleado.
         * @param activo Indica si el empleado esta activo.
         * @param oficina Oficina del empleado administrativo.
         * @param puesto Puesto del empleado administrativo.
         */
        public Empleado_Administrativo(int idEmpleado, double sueldo, DateTime dechaContratacion, bool activo, string? oficina, string? puesto) : base(idEmpleado, sueldo, dechaContratacion, activo)
        {
            _oficina = oficina;
            _puesto = puesto;
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la oficina del empleado administrativo.
         */
        public string? Oficina { get => _oficina; set => _oficina = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el puesto del empleado administrativo.
         */
        public string? Puesto { get => _puesto; set => _puesto = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Método para calcular el pago del empleado administrativo.
         * @return El pago calculado del empleado administrativo.
         */
        public override double CalculoPago()
        {
            throw new NotImplementedException();
        }
    }
}
