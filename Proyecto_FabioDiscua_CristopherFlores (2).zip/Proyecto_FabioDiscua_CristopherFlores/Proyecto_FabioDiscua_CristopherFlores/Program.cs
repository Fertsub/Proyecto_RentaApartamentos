﻿using Proyecto_FabioDiscua_CristopherFlores;
using System;
using System.Collections.Generic;

bool i = true;
bool z = true;

List<Apartamento> listApartamentos = new List<Apartamento>();
List<Arrendador> listArrendadores = new List<Arrendador>();
List<Arrendatario> listArrendatarios = new List<Arrendatario>();
List<Contrato> listContratos = new List<Contrato>();
List<Pago> listPagos=new List<Pago>();


/*
    Autor: [Cristopher Alexander Flores Miranda]
    Fecha: [18/02/2025]
    Parámetros: Ninguno
    Descripción: Método principal que gestiona el flujo del programa de gestión de apartamentos.
 */
while (i == true)
{
    z = true;

    Console.WriteLine("===================================================");
    Console.WriteLine("===================================================");
    Console.WriteLine("=========     GESTIÓN DE APARTAMENTOS     =========");
    Console.WriteLine("===================================================");
    Console.WriteLine("===================================================");
    Console.WriteLine("=== Seleccione una de las opciones disponibles ===");
    Console.WriteLine("");
    Console.WriteLine("--------------------------------------------------");
    Console.WriteLine("--------------------------------------------------");
    Console.WriteLine("");
    Console.WriteLine("1. Apartamentos");
    Console.WriteLine("2. Arrendadores");
    Console.WriteLine("3. Arrendatarios");
    Console.WriteLine("4. Contratos");
    Console.WriteLine("5. Pagos");
    Console.WriteLine("0. Salir");
    Console.WriteLine("");

    int optionX = Convert.ToInt32(Console.ReadLine());

    switch (optionX)
    {
        /*
            Autor: [Cristopher Alexander Flores Miranda]
            Fecha: [18/02/2025]
            Parámetros: Ninguno
            Descripción: Gestiona las operaciones relacionadas con los Apartamentos.
        */
        case 1:
            while (z == true)
            {
                Console.WriteLine("");
                Console.WriteLine("------------------------------------------");
                Console.WriteLine("------------------------------------------");
                Console.WriteLine("");
                Console.WriteLine("*********** APARTAMENTOS ***********");
                Console.WriteLine("");
                Console.WriteLine("1. Añadir Apartamento");
                Console.WriteLine("2. Eliminar Apartamento");
                Console.WriteLine("3. Editar Apartamento");
                Console.WriteLine("4. Mostrar Lista de Apartamentos");
                Console.WriteLine("0. Salir");
                Console.WriteLine("");
                Console.WriteLine("------------------------------------------");
                Console.WriteLine("-----------Seleccione una opción----------");
                Console.WriteLine("------------------------------------------");

                int option1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("");

                /*
                    Autor: [Cristopher Alexander Flores Miranda]
                    Fecha: [23/02/2025]
                    Parámetros: Ninguno
                    Descripción: Implementación de métodos para la gestión de Apartamentos
                */
                switch (option1)
                {
                    case 1:
                        Apartamento.Agregar(listApartamentos, listArrendadores);
                        break;

                    case 2:
                        Apartamento.Eliminar(listApartamentos);
                        break;

                    case 3:
                        Apartamento.Editar(listApartamentos, listArrendadores);
                        break;

                    case 4:
                        if (listApartamentos.Count == 0)
                        {
                            Console.WriteLine("No hay apartamentos registrados.");
                        }
                        else
                        {
                            Console.WriteLine("=== LISTA DE APARTAMENTOS ===");
                            foreach (Apartamento itApartamento in listApartamentos)
                            {
                                Console.WriteLine(itApartamento);
                            }
                        }
                        break;
                    case 0:
                        z = false;
                        break;

                    default:
                        Console.WriteLine("Opción inválida. Intente de nuevo.");
                        break;
                }
            }
            break;

        /*
            Autor: [Cristopher Alexander Flores Miranda]
            Fecha: [18/02/2025]
            Parámetros: Ninguno
            Descripción: Gestiona las operaciones relacionadas con los Arrendadores.
        */
        case 2:
            while (z == true)
            {
                Console.WriteLine("");
                Console.WriteLine("------------------------------------------");
                Console.WriteLine("------------------------------------------");
                Console.WriteLine("");
                Console.WriteLine("*********** ARRENDADORES ***********");
                Console.WriteLine("");
                Console.WriteLine("1. Añadir Arrendador");
                Console.WriteLine("2. Eliminar Arrendador");
                Console.WriteLine("3. Editar Arrendador");
                Console.WriteLine("4. Mostrar Lista de Arrendadores");
                Console.WriteLine("0. Salir");
                Console.WriteLine("");
                Console.WriteLine("------------------------------------------");
                Console.WriteLine("-----------Seleccione una opción----------");
                Console.WriteLine("------------------------------------------");

                int option2 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("");

                /*
                    Autor: [Cristopher Alexander Flores Miranda]
                    Fecha: [23/02/2025]
                    Parámetros: Ninguno
                    Descripción: Implementación de métodos para la gestión de Arrendadores
                */
                switch (option2)
                {
                    case 1:
                        Arrendador.Agregar(listArrendadores);
                        break;
                    case 2:
                        Arrendador.Eliminar(listArrendadores);
                        break;
                    case 3:
                        Arrendador.Editar(listArrendadores);
                        break;
                    case 4:
                        if (listArrendadores.Count == 0)
                        {
                            Console.WriteLine("No hay arrendadores registrados.");
                        }
                        else
                        {
                            Console.WriteLine("===== LISTA DE ARRENDADORES =====");
                            foreach (Arrendador itArrendador in listArrendadores)
                            {
                                Console.WriteLine(itArrendador);
                            }
                        }
                        break;

                    case 0:

                        z = false;
                        break;

                    default:
                        Console.WriteLine("Opción inválida. Intente de nuevo.");
                        break;
                }
            }


            break;

        /*
        Autor: [Cristopher Alexander Flores Miranda]
        Fecha: [18/02/2025]
        Parámetros: Ninguno
        Descripción: Gestiona las operaciones relacionadas con los Arrendatarios.
        */
        case 3:
            while (z == true)
            {
                Console.WriteLine("");
                Console.WriteLine("------------------------------------------");
                Console.WriteLine("------------------------------------------");
                Console.WriteLine("");
                Console.WriteLine("*********** ARRENDATARIOS ***********");
                Console.WriteLine("");
                Console.WriteLine("1. Añadir Arrendatario");
                Console.WriteLine("2. Eliminar Arrendatario");
                Console.WriteLine("3. Editar Arrendatario");
                Console.WriteLine("4. Mostrar Lista de Arrendatarios");
                Console.WriteLine("0. Salir");
                Console.WriteLine("");
                Console.WriteLine("------------------------------------------");
                Console.WriteLine("-----------Seleccione una opción----------");
                Console.WriteLine("------------------------------------------");

                int option3 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("");

                /*
                    Autor: [Cristopher Alexander Flores Miranda]
                    Fecha: [23/02/2025]
                    Parámetros: Ninguno
                    Descripción: Implementación de métodos para la gestión de Arrendatarios
                */
                switch (option3)
                {
                    case 1:
                        Arrendatario.Agregar(listArrendatarios);
                        break;
                    case 2:
                        Arrendatario.Eliminar(listArrendatarios);
                        break;
                    case 3:
                        Arrendatario.Editar(listArrendatarios);
                        break;
                    case 4:
                            if (listArrendatarios.Count == 0)
                            {
                                Console.WriteLine("No hay arrendatarios registrados.");
                            }
                            else
                            {
                                Console.WriteLine("===== LISTA DE ARRENDATARIOS =====");
                                foreach (Arrendatario itArrendatario in listArrendatarios)
                                {
                                    Console.WriteLine(itArrendatario);
                                }
                            }
                        break;
                    case 0:
                        z = false;
                        break;

                    default:
                        Console.WriteLine("Opción inválida. Intente de nuevo.");
                        break;
                }
            }

            break;
        /*
            Autor: [Cristopher Alexander Flores Miranda]
            Fecha: [18/02/2025]
            Parámetros: Ninguno
            Descripción: Gestiona las operaciones relacionadas con los Contratos.
        */
        case 4:
            while (z == true)
            {
                Console.WriteLine("");
                Console.WriteLine("------------------------------------------");
                Console.WriteLine("------------------------------------------");
                Console.WriteLine("");
                Console.WriteLine("*********** CONTRATOS ***********");
                Console.WriteLine("");
                Console.WriteLine("1. Añadir Contrato");
                Console.WriteLine("2. Eliminar Contrato");
                Console.WriteLine("3. Editar Contrato");
                Console.WriteLine("4. Mostrar Lista de Contratos");
                Console.WriteLine("0. Salir");
                Console.WriteLine("");
                Console.WriteLine("------------------------------------------");
                Console.WriteLine("-----------Seleccione una opción----------");
                Console.WriteLine("------------------------------------------");

                int option4 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("");

                /*
                    Autor: [Cristopher Alexander Flores Miranda]
                    Fecha: [23/02/2025]
                    Parámetros: Ninguno
                    Descripción: Implementación de métodos para la gestión de Contratos
                */
                switch (option4)
                {
                    case 1:
                        Contrato.Agregar(listContratos, listApartamentos, listArrendadores);
                        break;
                    case 2:
                        Contrato.Eliminar(listContratos);
                        break;
                    case 3:
                        Contrato.Editar(listContratos, listApartamentos, listArrendadores);
                        break;
                    case 4:
                        if (listContratos.Count == 0)
                        {
                            Console.WriteLine("No hay contratos registrados.");
                        }
                        else
                        {
                            Console.WriteLine("===== LISTA DE CONTRATOS =====");
                            foreach (Contrato itContrato in listContratos)
                            {
                                Console.WriteLine("**" + itContrato);
                            }
                        }
                        break;
                    case 0:
                        z = false;
                        break;

                    default:
                        Console.WriteLine("Opción inválida. Intente de nuevo.");
                        break;
                }
            }
            break;
        /*
            Autor: [Cristopher Alexander Flores Miranda]
            Fecha: [18/02/2025]
            Parámetros: Ninguno
            Descripción: Gestiona las operaciones relacionadas con Pagos.
        */
        case 5:
            while (z == true)
            {
                while (z == true)
                {
                    Console.WriteLine("");
                    Console.WriteLine("------------------------------------------");
                    Console.WriteLine("------------------------------------------");
                    Console.WriteLine("");
                    Console.WriteLine("*********** PAGOS ***********");
                    Console.WriteLine("");
                    Console.WriteLine("1. Añadir Pago");
                    Console.WriteLine("2. Eliminar Pago");
                    Console.WriteLine("3. Editar Pago");
                    Console.WriteLine("4. Mostrar Lista de Pagos");
                    Console.WriteLine("0. Salir");
                    Console.WriteLine("");
                    Console.WriteLine("------------------------------------------");
                    Console.WriteLine("-----------Seleccione una opción----------");
                    Console.WriteLine("------------------------------------------");

                    int option5 = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("");


                    /*
                    Autor: [Cristopher Alexander Flores Miranda]
                    Fecha: [23/02/2025]
                    Parámetros: Ninguno
                    Descripción: Implementación de métodos para la gestión de Pagos
                    */
                    switch (option5)
                    {
                        case 1:
                            Pago.Agregar(listPagos, listContratos);
                            break;
                        case 2:
                            Pago.Eliminar(listPagos);
                            break;
                        case 3:
                            Pago.Editar(listPagos, listContratos);
                            break;
                        case 4:
                            if (listPagos.Count == 0)
                            {
                                Console.WriteLine("No hay pagos registrados.");
                            }
                            else
                            {
                                Console.WriteLine("===== LISTA DE PAGOS =====");
                                foreach (Pago itPago in listPagos)
                                {
                                    Console.WriteLine(itPago);
                                }
                            }
                            break;
                        case 0:
                            z = false;
                            break;

                        default:
                            Console.WriteLine("Opción inválida. Intente de nuevo.");
                            break;
                    }
                }
            }
            break;
        case 0:
            i = false;
            break;

        default:
            Console.WriteLine("Opción inválida. Intente de nuevo.");
            break;
    }
}