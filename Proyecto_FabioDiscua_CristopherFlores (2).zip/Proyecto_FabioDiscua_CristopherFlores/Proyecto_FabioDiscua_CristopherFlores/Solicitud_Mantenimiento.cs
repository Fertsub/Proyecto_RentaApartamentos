﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_FabioDiscua_CristopherFlores
{
    internal class Solicitud_Mantenimiento
    {
        private int _idSol;
        private Apartamento? apartamento;
        private Arrendatario? arrendatario;
        private string? _descripcion;
        private float _costo;
        private DateTime _fechaRealizacion;
        private int _estado;

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor por defecto de la clase Solicitud_Mantenimiento.
         */
        public Solicitud_Mantenimiento() { }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor de la clase Solicitud_Mantenimiento.
         * @param idSol ID de la solicitud.
         * @param descripcion Descripción de la solicitud.
         * @param costo Costo de la solicitud.
         * @param fechaRealizacion Fecha de realización de la solicitud.
         * @param estado Estado de la solicitud.
         * @param apartamento Apartamento relacionado con la solicitud.
         * @param arrendatario Arrendatario que realiza la solicitud.
         */
        public Solicitud_Mantenimiento(int idSol, string? descripcion, float costo, DateTime fechaRealizacion, int estado, Apartamento? apartamento, Arrendatario? arrendatario)
        {
            IdSol = idSol;
            Descripcion = descripcion;
            Costo = costo;
            FechaRealizacion = fechaRealizacion;
            Estado = estado;
            Apartamento = apartamento;
            Arrendatario = arrendatario;
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el ID de la solicitud.
         */
        public int IdSol { get => _idSol; set => _idSol = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la descripción de la solicitud.
         */
        public string? Descripcion { get => _descripcion; set => _descripcion = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el costo de la solicitud.
         */
        public float Costo { get => _costo; set => _costo = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la fecha de realización de la solicitud.
         */
        public DateTime FechaRealizacion { get => _fechaRealizacion; set => _fechaRealizacion = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el estado de la solicitud.
         */
        public int Estado { get => _estado; set => _estado = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el apartamento relacionado con la solicitud.
         */
        internal Apartamento? Apartamento { get => apartamento; set => apartamento = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el arrendatario que realiza la solicitud.
         */
        internal Arrendatario? Arrendatario { get => arrendatario; set => arrendatario = value; }
    }
}
