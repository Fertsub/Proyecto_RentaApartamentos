﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_FabioDiscua_CristopherFlores
{
    internal class Pago
    {
        private int _idPago;
        private Contrato? contrato;
        private DateTime _fechaPago;
        private float _monto;
        private float _costoMensual;
        private int _estado;

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor por defecto de la clase Pago.
         */
        public Pago() { }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor de la clase Pago.
         * @param idPago ID del pago.
         * @param fechaPago Fecha del pago.
         * @param monto Monto del pago.
         * @param costoMensual Costo mensual del pago.
         * @param estado Estado del pago.
         * @param contrato Contrato asociado al pago.
         */
        public Pago(int idPago, DateTime fechaPago, float monto, float costoMensual, int estado, Contrato? contrato)
        {
            IdPago = idPago;
            FechaPago = fechaPago;
            Monto = monto;
            CostoMensual = costoMensual;
            Estado = estado;
            Contrato = contrato;
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el ID del pago.
         */
        public int IdPago { get => _idPago; set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Cuota Inválida");
                }
                else
                {
                    _idPago = value;
                }
            }
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la fecha del pago.
         */
        public DateTime FechaPago { get => _fechaPago; set
            {
                if (value == DateTime.MinValue)
                {
                    throw new ArgumentException("La fecha de pago no puede ser la fecha mínima.");
                }

                if (value > DateTime.Now)
                {
                    throw new ArgumentException("La fecha de pago no puede ser una fecha futura.");
                }

                if (value < new DateTime(2006, 1, 1))
                {
                    throw new ArgumentException("La fecha de pago no puede ser anterior al 1 de enero de 2006.");
                }

                _fechaPago = value;
            }
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el monto del pago.
         */
        public float Monto { get => _monto; set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Monto Inválido");
                }
                else
                {
                    _monto = value;
                }
            }
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el costo mensual del pago.
         */
        public float CostoMensual { get => _costoMensual; set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Costo Inválido");
                }
                else
                {
                    _costoMensual = value;
                }
            }
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el estado del pago.
         */
        public int Estado { get => _estado; set => _estado = (value == 1) ? 1 : 0;}

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el contrato asociado al pago.
         */
        internal Contrato? Contrato { get => contrato; set => contrato = value; }

        public override string ToString()
        {
            string estadoTexto = (_estado == 1) ? "Pagado" : "Pendiente";

            return $"\n[PAGOS]: ID Pago: {IdPago}| Contrato: {Contrato} | Fecha de Pago: {FechaPago} | Monto Total: {Monto} | Estado: {estadoTexto}";
        }

        /*
            Autor: [Cristopher Alexander Flores Miranda]
            Fecha: [23/02/2025]
            Parámetros: Ninguno
            Descripción: Gestiona las operaciones relacionadas con la clase Pago.
        */
        public static void Agregar(List<Pago> listPagos, List<Contrato> listContratos)
        {
            Console.WriteLine("===== AÑADIR NUEVO PAGO =====");

            Console.Write("Ingrese el ID del Pago: ");
            int idPago = Convert.ToInt32(Console.ReadLine());

            Console.Write("Ingrese la fecha de pago (YYYY-MM-DD): ");
            DateTime fechaPago = DateTime.Parse(Console.ReadLine() ?? "1900-01-01");

            Console.Write("Ingrese el monto pagado: ");
            float monto = float.Parse(Console.ReadLine() ?? "0");

            Console.Write("Ingrese el costo mensual: ");
            float costoMensual = float.Parse(Console.ReadLine() ?? "0");

            Console.Write("Ingrese el estado del pago (1: Pagado, 0: Pendiente): ");
            int estado = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\n***** Lista de Contratos *****");
            if (listContratos.Count == 0)
            {
                Console.WriteLine("No hay contratos registrados. Operación cancelada.");
                return;
            }
            foreach (Contrato itContrato in listContratos)
            {
                Console.WriteLine(itContrato);
            }

            Console.Write("\nIngrese el ID del Contrato para este pago: ");
            int idContratoSeleccionado = Convert.ToInt32(Console.ReadLine());

            Contrato? contratoSeleccionado = listContratos
                .FirstOrDefault(ct => ct.IdCont == idContratoSeleccionado);

            if (contratoSeleccionado == null)
            {
                Console.WriteLine("Contrato no encontrado. Operación cancelada.");
                return;
            }

            Pago nuevoPago = new Pago(
                idPago,
                fechaPago,
                monto,
                costoMensual,
                estado,
                contratoSeleccionado
            );

            listPagos.Add(nuevoPago);
            Console.WriteLine("¡Pago añadido con éxito!");
        }

        public static void Eliminar(List<Pago> listPagos)
        {
            if (listPagos.Count == 0)
            {
                Console.WriteLine("No hay pagos registrados.");
                return;
            }

            Console.WriteLine("===== ELIMINAR PAGO =====");

            Console.WriteLine("=== LISTA DE PAGOS ===");
            foreach (Pago itPago in listPagos)
            {
                Console.WriteLine(itPago);
            }

            Console.Write("Ingrese el ID del Pago a eliminar: ");
            int idEliminar = Convert.ToInt32(Console.ReadLine());

            Pago? pagoEliminar = listPagos.FirstOrDefault(pg => pg.IdPago == idEliminar);

            if (pagoEliminar != null)
            {
                listPagos.Remove(pagoEliminar);
                Console.WriteLine("Pago eliminado con éxito.");
            }
            else
            {
                Console.WriteLine("No se encontró un pago con ese ID.");
            }
        }

        public static void Editar(List<Pago> listPagos, List<Contrato> listContratos)
        {
            if (listPagos.Count == 0)
            {
                Console.WriteLine("No hay pagos registrados.");
                return;
            }

            Console.WriteLine("===== EDITAR PAGO =====");

            Console.WriteLine("=== LISTA DE PAGOS ===");
            foreach (Pago itPago in listPagos)
            {
                Console.WriteLine(itPago);
            }

            Console.Write("Ingrese el ID del Pago a editar: ");
            int idEditar = Convert.ToInt32(Console.ReadLine());

            Pago? aptoEditar = listPagos.FirstOrDefault(pg => pg.IdPago == idEditar);

            if (aptoEditar != null)
            {
                Console.Write("Nueva fecha de pago (YYYY-MM-DD): ");
                DateTime nuevaFechaPago = DateTime.Parse(Console.ReadLine() ?? "1900-01-01");

                Console.Write("Nuevo monto pagado: ");
                float nuevoMonto = float.Parse(Console.ReadLine() ?? "0");

                Console.Write("Nuevo costo mensual: ");
                float nuevoCostoMensual = float.Parse(Console.ReadLine() ?? "0");

                Console.Write("Nuevo estado (1: Pagado, 0: Pendiente): ");
                int nuevoEstado = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("\n¿Desea cambiar el Contrato? (S/N)");
                string? cambiarContrato = Console.ReadLine();
                if (cambiarContrato?.ToLower() == "S")
                {
                    Console.WriteLine("\n***** Lista de Contratos *****");
                    if (listContratos.Count == 0)
                    {
                        Console.WriteLine("No hay contratos registrados. Operación cancelada.");
                        return;
                    }
                    foreach (Contrato itContrato in listContratos)
                    {
                        Console.WriteLine(itContrato);
                    }

                    Console.Write("\nIngrese el nuevo ID de Contrato: ");
                    int nuevoIdContrato = Convert.ToInt32(Console.ReadLine());

                    Contrato? nuevoContrato = listContratos.FirstOrDefault(ct => ct.IdCont == nuevoIdContrato);

                    if (nuevoContrato != null)
                    {
                        aptoEditar.Contrato = nuevoContrato;
                    }
                    else
                    {
                        Console.WriteLine("Contrato no encontrado. Se mantiene el anterior.");
                    }
                }

                aptoEditar.FechaPago = nuevaFechaPago;
                aptoEditar.Monto = nuevoMonto;
                aptoEditar.CostoMensual = nuevoCostoMensual;
                aptoEditar.Estado= nuevoEstado;

                Console.WriteLine("Pago editado con éxito.");
            }
            else
            {
                Console.WriteLine("No se encontró un pago con ese ID.");
            }
        }
    }
}