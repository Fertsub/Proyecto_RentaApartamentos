﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_FabioDiscua_CristopherFlores
{
    internal class Arrendador : Persona
    {

        private string? _numRegistro;
        private string? _direccionResidencia;

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor por defecto de la clase Arrendador.
         */
        public Arrendador() { }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor de la clase Arrendador.
         * @param dni DNI del arrendador.
         * @param nombre Nombre del arrendador.
         * @param apellido Apellido del arrendador.
         * @param telefono Teléfono del arrendador.
         * @param correo Correo del arrendador.
         * @param numRegistro Número de registro del arrendador.
         * @param direccionResidencia Dirección de residencia del arrendador.
         */
        public Arrendador(int dni, string? nombre, string? apellido, string? telefono, string? correo, string? numRegistro, string? direccionResidencia) : base(dni, nombre, apellido, telefono, correo)
        {
            _numRegistro = numRegistro;
            _direccionResidencia = direccionResidencia;
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el número de registro del arrendador.
         */
        public string? NumRegistro { get => _numRegistro; set
            {
                if (value == null)
                {
                    throw new ArgumentException("Número de Registro no ingresado");
                }
                else
                {
                    _numRegistro = value;
                }
            }
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la dirección de residencia del arrendador.
         */
        public string? DireccionResidencia { get => _direccionResidencia; set
            {
                if (value == null)
                {
                    throw new ArgumentException("Dirección no ingresada");
                }
                else
                {
                    _direccionResidencia = value;
                }
            }
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Sobreescribe el método ToString() para mostrar la información del arrendador.
         * @return Una cadena con la información del arrendador.
         */
        public override string ToString()
        {
            return base.ToString() + $"Número de Registro: {NumRegistro} | Dirección de Residencia: {DireccionResidencia}";
        }

        public static void Agregar(List<Arrendador> listArrendadores)
        {

            Console.WriteLine("===== AÑADIR NUEVO ARRENDADOR =====");

            Console.Write("DNI: ");
            int dni = Convert.ToInt32(Console.ReadLine());

            Console.Write("Nombre: ");
            string? nombre = Console.ReadLine();

            Console.Write("Apellido: ");
            string? apellido = Console.ReadLine();

            Console.Write("Teléfono: ");
            string? telefono = Console.ReadLine();

            Console.Write("Correo: ");
            string? correo = Console.ReadLine();

            Console.Write("Número de Registro: ");
            string? numRegistro = Console.ReadLine();

            Console.Write("Dirección de Residencia: ");
            string? direccionResidencia = Console.ReadLine();

            Arrendador nuevoArrendador = new Arrendador(
                dni,
                nombre,
                apellido,
                telefono,
                correo,
                numRegistro,
                direccionResidencia
            );

            listArrendadores.Add(nuevoArrendador);
            Console.WriteLine("¡Arrendador añadido con éxito!");
        }

        public static void Eliminar(List<Arrendador> listArrendadores)
        {
            if (listArrendadores.Count == 0)
            {
                Console.WriteLine("No hay arrendadores registrados.");
                return;
            }

            Console.WriteLine("===== ELIMINAR ARRENDADOR =====");

            Console.WriteLine("=== LISTA DE ARRENDADORES ===");
            foreach (Arrendador itArrendador in listArrendadores)
            {
                Console.WriteLine(itArrendador);
            }

            Console.Write("Ingrese el DNI del arrendador a eliminar: ");
            int dniEliminar = Convert.ToInt32(Console.ReadLine());

            Arrendador? arrendadorEliminar = listArrendadores.FirstOrDefault(a => a.Dni == dniEliminar);

            if (arrendadorEliminar != null)
            {
                listArrendadores.Remove(arrendadorEliminar);
                Console.WriteLine("Arrendador eliminado con éxito.");
            }
            else
            {
                Console.WriteLine("No se encontró un arrendador con ese DNI.");
            }
        }

        public static void Editar(List<Arrendador> listArrendadores)
        {
            if (listArrendadores.Count == 0)
            {
                Console.WriteLine("No hay arrendadores registrados.");
                return;
            }

            Console.WriteLine("===== EDITAR ARRENDADOR =====");

            Console.WriteLine("=== LISTA DE ARRENDADORES ===");
            foreach (Arrendador itArrendador in listArrendadores)
            {
                Console.WriteLine(itArrendador);
            }

            Console.Write("Ingrese el DNI del arrendador a editar: ");
            int dniEditar = Convert.ToInt32(Console.ReadLine());

            Arrendador? aptoEditar = listArrendadores.FirstOrDefault(a => a.Dni == dniEditar);

            if (aptoEditar != null)
            {
                Console.WriteLine("Nuevo DNI: ");
                int nuevoDni=Convert.ToInt32(Console.ReadLine());

                Console.Write("Nuevo Nombre: ");
                string? nuevoNombre = Console.ReadLine();

                Console.Write("Nuevo Apellido: ");
                string? nuevoApellido = Console.ReadLine();

                Console.Write("Nuevo Teléfono: ");
                string? nuevoTelefono = Console.ReadLine();

                Console.Write("Nuevo Correo: ");
                string? nuevoCorreo = Console.ReadLine();

                Console.Write("Nuevo Número de Registro: ");
                string? nuevoNumRegistro = Console.ReadLine();

                Console.Write("Nueva Dirección de Residencia: ");
                string? nuevaDirResidencia = Console.ReadLine();

                aptoEditar.Dni = nuevoDni;
                aptoEditar.Nombre = nuevoNombre;
                aptoEditar.Apellido = nuevoApellido;
                aptoEditar.Telefono = nuevoTelefono;
                aptoEditar.Correo = nuevoCorreo;
                aptoEditar.NumRegistro= nuevoNumRegistro;
                aptoEditar.DireccionResidencia = nuevaDirResidencia;

                Console.WriteLine("Arrendador editado con éxito.");
            }
            else
            {
                Console.WriteLine("No se encontró un arrendador con ese DNI.");
            }
        }
    }
}
