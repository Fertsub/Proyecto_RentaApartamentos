﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_FabioDiscua_CristopherFlores
{
    internal abstract class Empleado
    {
        private int _idEmpleado;
        private double _sueldo;
        private DateTime _dechaContratacion;
        private bool _activo;

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor por defecto de la clase Empleado.
         */
        public Empleado()
        {
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor de la clase Empleado.
         * @param idEmpleado ID del empleado.
         * @param sueldo Sueldo del empleado.
         * @param dechaContratacion Fecha de contratación del empleado.
         * @param activo Indica si el empleado está activo.
         */
        public Empleado(int idEmpleado, double sueldo, DateTime dechaContratacion, bool activo)
        {
            IdEmpleado = idEmpleado;
            Sueldo = sueldo;
            DechaContratacion = dechaContratacion;
            Activo = activo;
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Método abstracto para calcular el pago del empleado.
         * Las clases derivadas deben implementar este método.
         * @return El pago calculado del empleado.
         */
        public abstract double CalculoPago();

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el ID del empleado.
         */
        public int IdEmpleado { get => _idEmpleado; set => _idEmpleado = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el sueldo del empleado.
         */
        public double Sueldo { get => _sueldo; set => _sueldo = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la fecha de contratación del empleado.
         */
        public DateTime DechaContratacion { get => _dechaContratacion; set => _dechaContratacion = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece si el empleado está activo.
         */
        public bool Activo { get => _activo; set => _activo = value; }
    }
}

