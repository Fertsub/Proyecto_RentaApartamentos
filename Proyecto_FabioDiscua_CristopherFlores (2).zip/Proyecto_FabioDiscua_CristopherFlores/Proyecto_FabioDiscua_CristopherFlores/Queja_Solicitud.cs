﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_FabioDiscua_CristopherFlores
{
    internal class Queja_Solicitud
    {
        private int _idQS;
        private Arrendatario? arrendatario;
        private Apartamento? apartamento;
        private string? _descripcion;
        private DateTime _fechaRegistro;
        private bool _estado;

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor por defecto de la clase Queja_Solicitud.
         */
        public Queja_Solicitud() { }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor de la clase Queja_Solicitud.
         * @param idQS ID de la queja o solicitud.
         * @param arrendatario Arrendatario que realiza la queja o solicitud.
         * @param apartamento Apartamento relacionado con la queja o solicitud.
         * @param descripcion Descripción de la queja o solicitud.
         * @param fechaRegistro Fecha de registro de la queja o solicitud.
         * @param estado Estado de la queja o solicitud.
         */
        public Queja_Solicitud(int idQS, Arrendatario? arrendatario, Apartamento? apartamento, string? descripcion, DateTime fechaRegistro, bool estado)
        {
            IdQS = idQS;
            Arrendatario = arrendatario;
            Apartamento = apartamento;
            Descripcion = descripcion;
            FechaRegistro = fechaRegistro;
            Estado = estado;
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el ID de la queja o solicitud.
         */
        public int IdQS { get => _idQS; set => _idQS = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el arrendatario que realiza la queja o solicitud.
         */
        internal Arrendatario? Arrendatario { get => arrendatario; set => arrendatario = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el apartamento relacionado con la queja o solicitud.
         */
        internal Apartamento? Apartamento { get => apartamento; set => apartamento = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la descripción de la queja o solicitud.
         */
        public string? Descripcion { get => _descripcion; set => _descripcion = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la fecha de registro de la queja o solicitud.
         */
        public DateTime FechaRegistro { get => _fechaRegistro; set => _fechaRegistro = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el estado de la queja o solicitud.
         */
        public bool Estado { get => _estado; set => _estado = value; }
    }
}
