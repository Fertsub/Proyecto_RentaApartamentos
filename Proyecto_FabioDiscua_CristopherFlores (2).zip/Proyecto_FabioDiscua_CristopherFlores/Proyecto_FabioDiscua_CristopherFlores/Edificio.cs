﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_FabioDiscua_CristopherFlores
{
    internal class Edificio
    {
        private int _idEdf;
        private string? _nombre;
        private string? _direccion;
        private int _numPisos;
        private Apartamento? apartamento;

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor por defecto de la clase Edificio.
         */
        public Edificio() { }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor de la clase Edificio.
         * @param idEdf ID del edificio.
         * @param nombre Nombre del edificio.
         * @param direccion Dirección del edificio.
         * @param numPisos Número de pisos del edificio.
         * @param apartamento Apartamento del edificio.
         */
        public Edificio(int idEdf, string? nombre, string? direccion, int numPisos, Apartamento? apartamento)
        {
            IdEdf = idEdf;
            Nombre = nombre;
            Direccion = direccion;
            NumPisos = numPisos;
            Apartamento = apartamento;
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el ID del edificio.
         */
        public int IdEdf { get => _idEdf; set => _idEdf = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el nombre del edificio.
         */
        public string? Nombre { get => _nombre; set => _nombre = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la dirección del edificio.
         */
        public string? Direccion { get => _direccion; set => _direccion = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el número de pisos del edificio.
         */
        public int NumPisos { get => _numPisos; set => _numPisos = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el Apartamento del edificio.
         */
        internal Apartamento? Apartamento { get => apartamento; set => apartamento = value; }
    }
}
