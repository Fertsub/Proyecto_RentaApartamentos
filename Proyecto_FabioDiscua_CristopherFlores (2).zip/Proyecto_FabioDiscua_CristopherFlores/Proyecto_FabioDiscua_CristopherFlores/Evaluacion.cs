﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_FabioDiscua_CristopherFlores
{
    internal class Evaluacion
    {
        private int _id;
        private int _calificacion;
        private string? _opinion;
        private DateTime _fecha;
        private Apartamento? apartamento;

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor por defecto de la clase Evaluacion.
         */
        public Evaluacion() { }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor de la clase Evaluacion.
         * @param id ID de la evaluación.
         * @param calificacion Calificación de la evaluación.
         * @param opinion Opinión de la evaluación.
         * @param fecha Fecha de la evaluación.
         * @param apartamento Apartamento de la evaluación.
         */
        public Evaluacion(int id, int calificacion, string? opinion, DateTime fecha, Apartamento? apartamento)
        {
            Id = id;
            Calificacion = calificacion;
            Opinion = opinion;
            Fecha = fecha;
            Apartamento = apartamento;
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el ID de la evaluación.
         */
        public int Id { get => _id; set => _id = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la calificación de la evaluación.
         */
        public int Calificacion { get => _calificacion; set => _calificacion = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la opinión de la evaluación.
         */
        public string? Opinion { get => _opinion; set => _opinion = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la fecha de la evaluación.
         */
        public DateTime Fecha { get => _fecha; set => _fecha = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el Apartamento de la evaluación.
         */
        internal Apartamento? Apartamento { get => apartamento; set => apartamento = value; }
    }
}
