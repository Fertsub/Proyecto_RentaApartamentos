﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_FabioDiscua_CristopherFlores
{
    internal class Factura
    {
        private int _idFact;
        private Contrato? contrato;
        private DateTime _fechaEmision;
        private float _montoTotal;
        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Enumeración para los servicios extra.
         */
        public enum ServicioExtra
        {
            CableInternet,
            Limpieza,
            Seguridad
        }

        /**
          * Autor: Cristopher Alexander Flores Miranda
          * Fecha: 17/02/2025
          * Enumeración para los planes de cable e internet.
          */
        public enum PlanCableInternet
        {
            Ninguno,
            Basico,
            Avanzado,
            Premium
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor por defecto de la clase Factura.
         */
        public Factura() { }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor de la clase Factura.
         * @param idFact ID de la factura.
         * @param fechaEmision Fecha de emisión de la factura.
         * @param montoTotal Monto total de la factura.
         * @param contrato Contrato asociado a la factura.
         */
        public Factura(int idFact, DateTime fechaEmision, float montoTotal, Contrato? contrato)
        {
            IdFact = idFact;
            FechaEmision = fechaEmision;
            MontoTotal = montoTotal;
            Contrato = contrato;
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el ID de la factura.
         */
        public int IdFact { get => _idFact; set => _idFact = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la fecha de emisión de la factura.
         */
        public DateTime FechaEmision { get => _fechaEmision; set => _fechaEmision = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el monto total de la factura.
         */
        public float MontoTotal { get => _montoTotal; set => _montoTotal = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el contrato asociado a la factura.
         */
        internal Contrato? Contrato { get => contrato; set => contrato = value; }
    }
}
