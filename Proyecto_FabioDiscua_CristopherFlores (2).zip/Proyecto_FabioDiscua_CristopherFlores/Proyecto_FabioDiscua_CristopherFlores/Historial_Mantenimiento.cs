﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_FabioDiscua_CristopherFlores
{
    internal class Historial_Mantenimiento
    {
        private int _idHisto;
        private Empleado? empleado;
        private Solicitud_Mantenimiento? solicitudMantenimiento;

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor por defecto de la clase Historial_Mantenimiento.
         */
        public Historial_Mantenimiento() { }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Constructor de la clase Historial_Mantenimiento.
         * @param idHisto ID del historial.
         * @param empleado Empleado asociado al historial.
         * @param solicitudMantenimiento Solicitud de mantenimiento asociada al historial.
         */
        public Historial_Mantenimiento(int idHisto, Empleado? empleado, Solicitud_Mantenimiento? solicitudMantenimiento)
        {
            IdHisto = idHisto;
            Empleado = empleado;
            SolicitudMantenimiento = solicitudMantenimiento;
        }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el ID del historial.
         */
        public int IdHisto { get => _idHisto; set => _idHisto = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece el empleado asociado al historial.
         */
        internal Empleado? Empleado { get => empleado; set => empleado = value; }

        /**
         * Autor: Cristopher Alexander Flores Miranda
         * Fecha: 17/02/2025
         * Obtiene o establece la solicitud de mantenimiento asociada al historial.
         */
        internal Solicitud_Mantenimiento? SolicitudMantenimiento { get => solicitudMantenimiento; set => solicitudMantenimiento = value; }
    }
}
